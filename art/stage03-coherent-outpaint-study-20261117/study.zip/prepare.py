from lxml import etree as E
from pathlib import Path
import copy,json
S='http://www.w3.org/2000/svg';P=Path('stage3-exterior-study/coherent-v3');r=E.parse('stage3-exterior-study/solid880/composite.svg').getroot();r.remove(r[-1]);defs=r[0]
c=E.SubElement(defs,'{%s}clipPath'%S,id='old-bottom',clipPathUnits='userSpaceOnUse');E.SubElement(c,'{%s}rect'%S,x='0',y='858',width='1774',height='29');sy=380/29
n=E.SubElement(r,'{%s}g'%S,transform=f'matrix(1 0 0 {sy} 0 {887-858*sy})',attrib={'clip-path':'url(#old-bottom)'});E.SubElement(n,'{%s}use'%S,href='#original-body')
r.set('viewBox','-1200 0 4174 3400');r.set('width','1670');r.set('height','1360');(P/'original-collage.svg').write_bytes(E.tostring(r))
line=[[0,684],[150,687],[190,715],[214,748],[281,758],[428,761],[493,790],[599,811],[680,808],[729,788],[764,749],[798,718],[923,716],[980,701],[1070,702],[1192,731],[1354,729],[1438,695],[1487,660],[1520,644],[1774,638]]
d='M0 0 H1774 '+ ' '.join(('L'+str(x)+' '+str(y+44)) for x,y in reversed(line))+' Z'
m=E.Element('{%s}svg'%S,nsmap={None:S},viewBox='-1200 0 4174 3400',width='1670',height='1360');E.SubElement(m,'{%s}path'%S,d=d,fill='white')
for x,y,w,h in [(-1200/3.23,640,1200/3.23,88),(1774,594,1200/3.23,88)]:E.SubElement(m,'{%s}rect'%S,x=str(x),y=str(y),width=str(w),height=str(h),fill='white')
(P/'semantic-mask.svg').write_bytes(E.tostring(m))
(P/'contract.json').write_text(json.dumps({'referenceViewBox':[-1200,0,4174,3400],'referencePixels':[1670,1360],'floorPolyline':line,'marginSource':44,'coreMask':'0<=x<=1774,0<=y<=ferry-ground(x)+44,including transparent arch/air','sideBands':[[-371.5170278637771,640,371.5170278637771,88],[1774,594,371.5170278637771,88]],'sideGroundY':[684,638],'preserveOtherProviders':['landmarks','ferry','lantern','spirit-flame'],'mutable':'nonwalking geology outside mask; old artificial strips not globally protected','sourceGeometryChanged':False},indent=2))
