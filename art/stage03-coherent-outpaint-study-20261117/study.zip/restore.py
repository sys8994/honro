from lxml import etree as E
from PIL import Image
from pathlib import Path
import json,subprocess,numpy as np,base64,copy
P=Path('stage3-exterior-study/coherent-v3');w,h=Image.open(P/'generated.png').size;H=h*4174/w;S='http://www.w3.org/2000/svg'
for n in ['original-collage','semantic-mask']:
 r=E.parse(str(P/(n+'.svg')));r.getroot().set('viewBox',f'-1200 0 4174 {H}');r.getroot().set('width',str(w));r.getroot().set('height',str(h));r.write(str(P/(n+'-registered.svg')))
 subprocess.run(['inkscape',str(P/(n+'-registered.svg')),'--export-area-page','--export-filename='+str(P/(n+'-registered.png'))],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
a=np.array(Image.open(P/'original-collage-registered.png').convert('RGBA'));b=np.array(Image.open(P/'generated.png').convert('RGBA'));m=np.array(Image.open(P/'semantic-mask-registered.png').convert('RGBA'))[:,:,3]>0;c=b.copy();c[m]=a[m];Image.fromarray(c).save(P/'restored.png')
report={'size':[w,h],'viewBox':[-1200,0,4174,H],'uniformGeneratedPixelToSource':4174/w,'protectedPixels':int(m.sum()),'transparentProtectedPixels':int((m&(a[:,:,3]==0)).sum()),'protectedChanged':int(np.any(c[m]!=a[m],axis=1).sum()),'generatedDiscardedProtected':True,'sourceAndPhysicsUnmodified':True}
(P/'restoration.json').write_text(json.dumps(report,indent=2));print(report)
r=E.Element('{%s}svg'%S,nsmap={None:S});E.SubElement(r,'{%s}image'%S,x='-1200',y='0',width='4174',height=str(H),href='data:image/png;base64,'+base64.b64encode((P/'restored.png').read_bytes()).decode())
scale=390/6800*3.23;cy=3035.01/3.23
views=[('join','0 600 1774 500',1200,338)]
for name,cx in [('portrait-left',0),('portrait-right',1774)]:views.append((name,f'{cx-390/scale/2} {cy-844/scale/2} {390/scale} {844/scale}',390,844))
for name,v,pw,ph in views:
 q=copy.deepcopy(r);q.set('viewBox',v);q.set('width',str(pw));q.set('height',str(ph));E.ElementTree(q).write(str(P/(name+'.svg')));subprocess.run(['inkscape',str(P/(name+'.svg')),'--export-area-page','--export-filename='+str(P/(name+'.png'))],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
