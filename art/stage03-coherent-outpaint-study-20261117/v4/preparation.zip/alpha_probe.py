from PIL import Image
from scipy.ndimage import label
from lxml import etree as E
from pathlib import Path
import numpy as np,base64,json,subprocess
P=Path('stage3-exterior-study/coherent-v4');old=Path('stage3-exterior-study/coherent-v3');a=np.array(Image.open(old/'restored.png').convert('RGBA'));raw=np.array(Image.open(old/'generated.png').convert('RGBA'));mask=np.array(Image.open(old/'semantic-mask-registered.png').convert('RGBA'))[:,:,3]>0
labs,n=label(raw[:,:,3]>0);counts=np.bincount(labs.ravel());main=1+counts[1:].argmax();d=(labs!=0)&(labs!=main)&~mask
b=a.copy();b[d]=0;Image.fromarray(b).save(P/'v3-detached-clean.png')
S='http://www.w3.org/2000/svg';W=390;H=696;scale=390/6800*3.23;v=f'{-W/scale/2} {3035.01/3.23-H/scale/2} {W/scale} {H/scale}'
for name,img in [('with-dirt',old/'restored.png'),('without-dirt',P/'v3-detached-clean.png')]:
 r=E.Element('{%s}svg'%S,nsmap={None:S},width=str(W),height=str(H),viewBox=v);E.SubElement(r,'{%s}image'%S,x='-1200',y='0',width='4174',height=str(1132*4174/1390),href='data:image/png;base64,'+base64.b64encode(img.read_bytes()).decode());E.ElementTree(r).write(str(P/(name+'.svg')))
 subprocess.run(['inkscape',str(P/(name+'.svg')),'--export-area-page','--export-filename='+str(P/(name+'.png'))],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 bg=Image.open('stage3-safe-review/safe/stage3-candidate-portrait-bl.png').convert('RGBA');bg.alpha_composite(Image.open(P/(name+'.png')).convert('RGBA'));bg.save(P/(name+'-actual-background.png'))
x=np.array(Image.open(P/'with-dirt-actual-background.png')).astype(int);y=np.array(Image.open(P/'without-dirt-actual-background.png')).astype(int);diff=np.abs(x-y);report={'outsideProtectedDetachedPixels':int(d.sum()),'alphaCounts':dict(zip(*[v.tolist() for v in np.unique(raw[:,:,3][d],return_counts=True)])),'maxAlpha':int(raw[:,:,3][d].max()),'actualBackdropPixelChanges':int((diff.max(2)>0).sum()),'maxActualBackdropDelta':int(diff.max()),'protectedRgbaChanges':int(np.any(a[mask]!=b[mask],axis=1).sum()),'scope':'Native registered overlay on actual Chrome safe Scene PNG as background, not newly executed Scene'}
(P/'alpha-report.json').write_text(json.dumps(report,indent=2));print(report)
