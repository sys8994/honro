from pathlib import Path
from PIL import Image
import numpy as np,json,re
P=Path('stage3-exterior-study/final-wait');v3=Path('stage3-exterior-study/coherent-v3');a=np.array(Image.open(v3/'original-collage-registered.png').convert('RGBA'));b=np.array(Image.open(v3/'restored.png').convert('RGBA'));m=np.array(Image.open(v3/'semantic-mask-registered.png').convert('RGBA'))[:,:,3]>0
h,w=a.shape[:2];scale=4174/w;y,x=np.indices((h,w));sx=(x+.5)*scale-1200;sy=(y+.5)*scale
contract=json.load(open(v3/'contract.json'));lines={'ferry-ground':contract['floorPolyline']}
s=Path('/tmp/naru-7d2.mjs').read_text().split('const naru={',1)[1].split('const village=',1)[0]
for name,arr in re.findall(r"'([^']+)':(\[\[.*?\]\])",s):lines[name]=json.loads(arr)
lines['ground-left-extension']=[[-1200/3.23,684],[0,684]];lines['ground-right-extension']=[[1774,638],[1774+1200/3.23,638]]
rows=[];total=np.zeros((h,w),bool)
for name,pts in lines.items():
 d=np.full((h,w),np.inf)
 for p,q in zip(pts,pts[1:]):
  px,py=p;qx,qy=q;vx=qx-px;vy=qy-py;t=np.clip(((sx-px)*vx+(sy-py)*vy)/(vx*vx+vy*vy),0,1);d=np.minimum(d,(sx-px-t*vx)**2+(sy-py-t*vy)**2)
 band=d<=6**2;total|=band;diff=np.abs(a[band].astype(int)-b[band].astype(int))
 rows.append({'id':name,'sourcePoints':pts,'bandRadiusSource':6,'sampledPixels':int(band.sum()),'notProtected':int((band&~m).sum()),'changedRGBA':int(np.any(diff,axis=1).sum()),'maxRGBA':int(diff.max()) if len(diff) else None,'baselineTransparentPixels':int((band&(a[:,:,3]==0)).sum())})
diff=np.abs(a[m].astype(int)-b[m].astype(int))
# Diagnostic classifier, not an authorized cleanup/paint mask.
outside=(sx < -1200/3.23)|(sx >1774+1200/3.23)
olive=outside&(sy<1100)&~m&(b[:,:,3]>=128)&(b[:,:,1].astype(int)>b[:,:,0].astype(int)+8)&(b[:,:,1].astype(int)>b[:,:,2].astype(int)+12)&(b[:,:,1]>50)
ys,xs=np.where(olive);bbox=[float(sx[ys,xs].min()),float(sy[ys,xs].min()),float(sx[ys,xs].max()),float(sy[ys,xs].max())] if len(xs) else None
center=(sx>=380)&(sx<=1250)&(sy>=855)&(sy<=1450)&~m
for name,mask in [('olive-outside-ground',olive),('inherited-stretch-inspection-roi',center)]:
 im=np.zeros((h,w,4),np.uint8);im[mask]=[255,80,30,200];Image.fromarray(im).save(P/(name+'.png'))
report={'reference':'native original public collage at same1390x1132 uniform registration, not actual Chrome','candidate':'v3 restored study, unchanged','protected':{'pixels':int(m.sum()),'rgbaChanged':int(np.any(diff,axis=1).sum()),'max':int(diff.max()),'transparentPixels':int((m&(a[:,:,3]==0)).sum())},'contactBands':rows,'allContactUnionPixels':int(total.sum()),'allContactUnionChanged':int(np.any(a[total]!=b[total],axis=1).sum()),'diagnosticOliveOutside':{'pixels':int(olive.sum()),'bboxSource':bbox,'rule':'alpha>=128,G>R+8,G>B+12,G>50,sourceY<1100,outside actual ground x range; diagnostic only, not semantic authority or cleanup approval'},'centralStretchROI':{'source':[380,855,1250,1450],'pixels':int(center.sum()),'notExactObjectMask':True},'physicsAndProductionModified':False,'imageGenerationRetried':False,'status':'waiting, unaccepted; valid integration keeps original Stage3'}
(P/'quantitative-review.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
# Supplemental distinction, not replacement/weakening of round-cap failures above.
interior=[]
for name,pts in lines.items():
 inside=np.zeros((h,w),bool)
 for (px,py),(qx,qy) in zip(pts,pts[1:]):
  vx=qx-px;vy=qy-py;t=((sx-px)*vx+(sy-py)*vy)/(vx*vx+vy*vy);dd=(sx-px-t*vx)**2+(sy-py-t*vy)**2
  inside|=(t>=0)&(t<=1)&(dd<=36)
 interior.append({'id':name,'pixels':int(inside.sum()),'changes':int(np.any(a[inside]!=b[inside],axis=1).sum())})
(P/'contact-segment-interiors.json').write_text(json.dumps(interior,indent=2))
