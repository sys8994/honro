#!/usr/bin/env python3
"""Exact final-assembly replay from frozen authored planes + existing aux input.
Does not regenerate semantic authoring from rawtrace and never writes its input.
"""
from pathlib import Path
import argparse,json,hashlib,re,copy,xml.etree.ElementTree as ET
from svgpathtools import parse_path
ROOT=Path(__file__).resolve().parents[1]
FINAL='1afeaf3218259130c0c21964483bb26e31f683d3a6a31d6ff726f687efcee248'
BASE='35ea9ea23ef51a3e7fc71282bc9e709d7da445774b14730cfeac6af3ad4be0e9'
ASSET='approved34:east-v6-connected-diagnostic';ELEMENT='approved34-east-v6-connected'
def encoded(v):return json.dumps(v,separators=(',',':')).encode()
def digest(v):return hashlib.sha256(v).hexdigest()
def svg(asset):
 v=asset['vector'];ns='http://www.w3.org/2000/svg';ET.register_namespace('',ns)
 r=ET.Element('{'+ns+'}svg',{'width':'1300','height':'2700','viewBox':'0 0 1300 2700'})
 defs=ET.SubElement(r,'{'+ns+'}defs')
 for key,paths in v['clips'].items():
  cp=ET.SubElement(defs,'{'+ns+'}clipPath',{'id':key,'clipPathUnits':'userSpaceOnUse'})
  for d in paths:ET.SubElement(cp,'{'+ns+'}path',{'d':d})
 def emit(parent,n):
  a={}; names={'fill':'fill','stroke':'stroke','lineWidth':'stroke-width','lineJoin':'stroke-linejoin','lineCap':'stroke-linecap','fillRule':'fill-rule','opacity':'opacity'}
  for key,target in names.items():
   if key in n:a[target]=str(n[key])
  if 'd'in n or'dParts'in n:a['d']=n.get('d')or' '.join(n['dParts'])
  if 'clipPath'in n:a['clip-path']='url(#'+n['clipPath']+')'
  if 'transform'in n:a['transform']='matrix('+' '.join(map(str,n['transform']))+')'
  e=ET.SubElement(parent,'{'+ns+'}'+n['tag'],a)
  for c in n.get('children',[]):emit(e,c)
 emit(r,v['root']);return ET.tostring(r,encoding='utf-8',xml_declaration=True)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--base-input',type=Path,required=True,help='Existing aux1afe candidate OR exact35ea base; read-only');ap.add_argument('--output-dir',type=Path,required=True);args=ap.parse_args()
 raw=args.base_input.read_bytes();h=digest(raw);assert h in [FINAL,BASE],f'Unapproved base input SHA: {h}';p=json.loads(raw)
 if h==FINAL:
  assert sum(a['id']==ASSET for a in p['library'])==1;p['library']=[a for a in p['library']if a['id']!=ASSET]
  stage=next(s for s in p['stages']if s['metadata']['stageId']==34)
  assert sum(e['id']==ELEMENT for e in stage['elements'])==1;stage['elements']=[e for e in stage['elements']if e['id']!=ELEMENT]
 assert digest(encoded(p))==BASE,'Derived35ea does not match frozen base'
 a=json.loads((ROOT/'authoring/pre-cull-asset.json').read_text());v=a['vector'];g=v['root']['children'][0]
 assert v['clips']==json.loads((ROOT/'authoring/final-clips.json').read_text())
 boxes=[parse_path(d).bbox()for d in v['clips'][g['clipPath']]];bound=[min(x[0]for x in boxes),max(x[1]for x in boxes),min(x[2]for x in boxes),max(x[3]for x in boxes)]
 removed=before=after=0
 for n in g['children']:
  pieces=parse_path(n['d']).continuous_subpaths();chunks=re.findall(r'M[^M]*',n['d']);assert'm'not in n['d']and len(chunks)==len(pieces)
  radius=n.get('lineWidth',0)/2 if n.get('stroke','none')!='none'else 0;keep=[]
  for q,text in zip(pieces,chunks):
   b=q.bbox();before+=len(q)
   outside=b[1]+radius<bound[0]or b[0]-radius>bound[1]or b[3]+radius<bound[2]or b[2]-radius>bound[3]
   if outside:removed+=1
   else:keep.append(text);after+=len(q)
  n['d']=''.join(keep)
 a['params']['optimization']='Only complete subpaths whose exactBezierbbox+strokeRadius is disjoint from finalclipBBox removed; all others preserved includingholes/enclosingcontours. No simplification.'
 assert(removed,before,after)==(565,9940,5426)
 p['library'].append(a);stage=next(s for s in p['stages']if s['metadata']['stageId']==34);stage['elements'].append(json.loads((ROOT/'authoring/element.json').read_text()))
 out=encoded(p);assert digest(out)==FINAL,'Final candidate differs from selected1afe';O=args.output_dir.resolve();O.mkdir(parents=True,exist_ok=True);assert args.base_input.resolve()!=O/'candidate.json'
 (O/'candidate.json').write_bytes(out);(O/'final-asset.json').write_bytes(encoded(a));(O/'final-world-unit.svg').write_bytes(svg(a))
 report={'inputSha256':h,'derivedBaseSha256':BASE,'candidateSha256':digest(out),'candidateBytes':len(out),'assetSha256':digest(encoded(a)),'removedSubpaths':removed,'colorSegmentsBefore':before,'colorSegmentsAfter':after,'clipBBoxSource':bound,'bboxOrder':['xMin','xMax','yMin','yMax'],'inputUnchanged':digest(args.base_input.read_bytes())==h,'scope':'Exact final assembly from frozen authored planes. Rawtrace-to-semanticauthoring decisions are preserved inputs, not claimed automatically recomputed.'}
 (O/'reproduction-report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
if __name__=='__main__':main()
