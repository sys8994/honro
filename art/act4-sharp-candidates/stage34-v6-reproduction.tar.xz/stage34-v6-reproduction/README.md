# Stage34 v6 minimal production replay

## Selected artifact and browser status

Final candidate SHA: `1afeaf3218259130c0c21964483bb26e31f683d3a6a31d6ff726f687efcee248`.
Parent reported actual Chromium connection review **passed at83f579ea**, selected by auxiliary `REVIEW_INDEX v3` at `6f65b57fa7d389daec0f3932c7b094cff1b2dcc9`, and requested common integration. This archive records that parent-reported result; historical QA documents retain their original pre-Chrome "pending" labels. It does not claim a new normal-gameplay run.

This archive deliberately excludes the full candidate (already in aux), original five large assets,71scenePNGs, rejected candidates and temporary output. Local originals remain untouched. It contains the final source PNG, actual native Inkscape traces/logs, finalSVGs, authored geometry/masks, small executable replay scripts and SOP evidence.

## Reproduction boundary — explicit, not a hidden dependency

There are two different operations:
1. **Source→raw trace:** replayable with the archived original Inkscape script and source PNG. Exact historical traces are preserved. Inkscape-generated IDs/metadata/absolute paths can differ across installations; source geometry/alpha and documented metrics must be compared, rather than assuming SVGbyteidentity.
2. **Authored state→exact selected candidate:** deterministic and locally verified. `authoring/pre-cull-asset.json` freezes the reviewed natural-face selection, local palette assignments, original beige/dark curve partitions and overlaps. It includes all operative clips. The small replay script removes only the565irrelevant absolute-M chunks and assembles the final artifact with an exact base.

**The second operation does not automatically infer all semantic art choices from the raw trace.** Those approved choices are the compact authored intermediate, analogous to a saved vector editor document. The original investigation scripts/rejected alternatives remain local; the archive does not pretend to replay that exploratory history or regenerate imagegen stochastically.

## No duplicated35ea payload required

Provide the already archived aux1afe candidate as a **read-only input**. Removing exactly the appended v6asset/element reconstructs35ea byte-for-byte:
- base SHA `35ea9ea23ef51a3e7fc71282bc9e709d7da445774b14730cfeac6af3ad4be0e9`
- base length4,706,956bytes.

Replaying the archived authored asset and safe cull then reproduces final1afe,4,894,892bytes, exactly. This was independently verified twice. The script also accepts the exact35ea candidate directly. It rejects any other input hash and never overwrites the input. **The aux/base input is required and intentionally not bundled.**

## Exact commands

Recorded environment: Python3, `svgpathtools==1.7.2`; tracing additionally used Inkscape1.4(e7c3feb100,2024-10-09), Pillow13.0.0, NumPy2.3.5, SciPy1.17.0, lxml6.1.1. No installation command or network access is performed by the scripts.

From the extracted archive root:

```sh
sha256sum -c SHA256SUMS
python scripts/reproduce.py \
  --base-input /path/to/already-archived-aux-stage34-candidate.json \
  --output-dir ../stage34-replayed
sha256sum ../stage34-replayed/candidate.json
# Expected: 1afeaf3218259130c0c21964483bb26e31f683d3a6a31d6ff726f687efcee248
```

The output includes a candidate, final asset, world-unitSVG and a replay report. These generated outputs are deliberately outside the source archive.

A fresh trace replay from this extracted-style standalone directory also completed successfully: nearest-opaque input, colorraw, alpha raw, combinedraw, compactSVG and both comparison renderPNGs were all byteexact against the historical run. See `evidence/actual-trace-replay-report.json`. The extra generated PNGs remain local. This is observed reproducibility in the recorded environment, not a promise across all Inkscape versions. The archived script's optional simplification loop is empty; no external geometry helper is executed.

Optional source retrace in a suitable Inkscape environment:

```sh
python scripts/trace-nonstacked.py \
  source/generated-east-connection-v2-flat.png ../stage34-retrace 8 true 0
```

The historical headless environment used a small C++ wrapper-initialization helper. Its source is included; build it locally (the replay check rebuilt the exact historical binary SHA):

```sh
g++ -shared -fPIC scripts/init-wrappers.cpp -o ../stage34-init-wrappers.so \
  -Wl,--no-as-needed -l:libglibmm-2.4.so.1 -l:libgdkmm-3.0.so.1 \
  -l:libpangomm-1.4.so.1 -l:libgtkmm-3.0.so.1
```

Then:

```sh
HONRO_INKSCAPE_PRELOAD="$(realpath ../stage34-init-wrappers.so)" \
  python scripts/trace-nonstacked.py \
  source/generated-east-connection-v2-flat.png ../stage34-retrace 8 true 0
```

The helper only initializes the standard Glib/Gdk/Pango/Gtk wrappers omitted by this headless Inkscape build; it does not change the tracing algorithm. Its historical/rebuilt binary hash is recorded, but no platform-specific binary is bundled. It is not required on a normal tracing-capable desktop. It is unrelated to Chromium or the game renderer. Use the actual environment-supported tracing route; do not silently replace tracing with a fabricated SVG.

Actual color action: `object-trace:8,true,false,false,0,1,0.2`.
Actual alpha action: `object-trace:2,false,false,true,0,0,0.1`.
Technical nearest-opaque RGB input regenerates from the source, so its duplicatePNG is omitted; expected SHA `44ed1e06749417a9cd93f37b066682cf689ce6c1cb715b0dd29e46930a2c7944`.

## Coordinate / mask contract

- Source image:870×1808, SHA `29992cc5f66adb64c8c9810b0d37bbc2278aaf50389495bde4e1cbb8979c11f2`.
- Asset placement: world(5600,600), size1300×2700.
- `final/final-world-unit.svg` includes the root scale1300/870 horizontally and2700/1808 vertically.
- `final/final-source-grid.svg` is the exact actual-paint QA SVG in source coordinates; its3480×7232 output is4×sampling, **not** world placement.
- `authoring/final-clips.json` is the operative clip data, also embedded byte-for-byte in the authored asset.
- `final/semantic-mask-source-grid.svg` is the target semantic mask for QA, not an interchangeable runtime clip.
- Original BODY remains4world/sourcepx; original coast remains6world/sourcepx. Registration details are in `final/registration.json`.

## Preserved evidence

`trace/` stores actual sourcecolor/alpha traces and original command logs. `evidence/assembly-reproduction-report.json` records an executed exact replay. `evidence/FINAL-1AFE-VALIDATION.json` and `structure.json` preserve selected alpha/guard/data checks. `docs/` retains the original STATUS and detailed reproduction/precision limits. `SOP-재발방지.md` is the concise rule set for future work.

All71scenePNGs and AA heatmaps remain local in the original report, not copied here. Existing runtime/common repository files must not be overwritten when preserving this archive.
