# Final selected SHA addendum

Root selected candidate SHA256 `1afeaf3218259130c0c21964483bb26e31f683d3a6a31d6ff726f687efcee248`.

`FINAL-1AFE-VALIDATION.json` directly measures that candidate's existing actual emitted SVG4× paint, including every clip, stroke and added plane. These are not copied or inferred from d847:
- Semantic mask missing30 / extra95 samples; maximum distances .25 / .25 generatedsourcepx.
- Interior2,986,927 samples; alpha0=0; alpha<128=30; minimum21; maximumgapradius.25sourcepx.
- Actualpaint alpha>0 outside original generatedsource opaquealpha:0.
- Actualpaint alpha>0 on actualwalk/foot/compositeexterior/lower3100 guard:0.

The earlier FINAL report's d847 measurements remain historically labeled. Parent separately completed71-view comparison and direct visual review. ActualChromium and normalgameplay remain separate gates. No artwork or optimization was changed in this addendum.
