# Stage34 v6 — registered connection / precision / limitations

## Reviewed candidates
- Art-reviewed unculled: `candidate-dark-visible-review.json`, SHA256 `d847c07dda88af8318d694480befa4c32151ae16385f674640b97b93db41f1ad`.
- Conservative cull comparison/recommendation: `optimization/candidate-exact-chunk-cull.json`, SHA256 `1afeaf3218259130c0c21964483bb26e31f683d3a6a31d6ff726f687efcee248`.
- Final selection, complete 71-view review, costs and cloud Chromium handoff belong to parent. Native art review is not actual Chromium acceptance or normal gameplay validation.

## Source and coordinates
- Generated v2-flat source: `../../generated-east-connection-v2-flat.png`, SHA256 `29992cc5f66adb64c8c9810b0d37bbc2278aaf50389495bde4e1cbb8979c11f2`, 870×1808.
- Source registered at world (5600,600), size1300×2700. X scale1300/870, Y scale2700/1808. The small anisotropy exactly matches the approved reference bounds. Original BODY remains4world/sourcepx; original coast remains6world/sourcepx and origin(-1536,-256).
- Source original preserved. Hidden RGB technical trace input uses nearest opaque RGB, never white fill. Technical input hash/logs are in trace8/metrics.json.
- Actual Inkscape color action: `object-trace:8,true,false,false,0,1,0.2`, native nonstack8colors, speckles0. Color and alpha traced independently. `trace8/02-inkscape-color-trace-unclipped.svg` preserves full source color coverage.
- Trace12 was rejected for excess intermediate tonal bands and larger internal holes. No new generated image was used after v2-flat.

## Authoring vs precision
The connection mask is an authorized selection/authoring change, not a claim that the entire new connection differs from the original art by≤1.5px. Reused natural BODY/coast/source curve chains and explicitly recorded same-field closures define its extent. Old wrong color cuts were not protected as immutable pixels.

Precision of representations is separately measured:
1. Generatedsource→raw8 alpha silhouette maximum1.41421356sourcepx. Independent interior diagnostic also finds raw internal gaps up to1.414px across the full source; provisional corridor≤1px. This is not a blanket coverage pass.
2. Raw color→compact absolute control rounding has bound√2×.005=.007071sourcepx. Relative command encoding is chosen only after absolute coordinates are rounded. No curve simplification.
3. Same-fill overlap radius .3sourcepx normally, .5sourcepx only on measured color1/5 gaps. Maximum generatedcolor geometry envelope change≤.507071sourcepx. This is explicit overlap authoring, not an invisible optimization.
4. Whole-face technical mask closes only tiny color-selection gaps at4samples/sourcepx, radius.5px, then actual Inkscape alpha trace. Latest pre-partition mask extra extent≤1.060660sourcepx; technicalmask→native trace missing/extra≤.25px. Compact bound≤.007071px. Sourceopaque and physical guard tests0.
5. Original BODY beige tip uses original full color curves at their original world positions (authoring displacement0), actual Inkscape intersection, then visible-color partition subtracting all later colors. Only10 nonempty tiny planes survive. Same-fill stroke width.16world, radius.08world=.02BODYsourcepx. The old BODY asset itself is unchanged.
6. Darkbottom planes are actual originalcoast visible12=12−13−14−15,14=14−15,and the relevant15 naturalcomponent126, intersected with the scoped dark face. Selecting only12−13 was disproven; it changed the visiblegreen area and is not the final method. Three selected visible planes preserve original curve provenance; original coast asset is unchanged.

## Actual final emitted alpha, not scope-mask-only
`final-d847-standalone4x/` renders all final root children, strokes and clips without the original BODY or background beneath them.
- Target selectedmask vs actualpaint: missing30 samples, extra95samples, each maximum distance.25generatedsourcepx at4samples/sourcepixel.
- Interior2,986,927samples: alpha0=0, alpha<128=30, minimum21, maximum gapradius.25sourcepx. Normal color-boundary AA is distinguished from holes; do not claim every pixel is opaque.
- Actualpaint alpha>0 outside generatedsource opaquealpha:0; actualpaint alpha>0 on conservative actualfoot/walk/exterior/lower3100 protection:0.
- New samefill overlap and originalplane partition are included in these emitted SVG checks, not omitted from validation.

## Preservation
Independent checker reports in `../independent-validation/review-d847` and `review-1afe`:
- Original5 assets, originalelements and their order, all stages/terrain/actors/story/project records exact after removing only the appended asset and element.
- Local1world and full.25world composed alpha bytechanges0.
- Actualfoot/walk, compositeouter and3100+ protectedRGBA changes0;3090buffer0.
- Approved sameface changes above1400 are counted separately (7508pixels at local sampling), not incorrectly treated as a fixed authoring wall.
- No shared renderer/runtime/source/remote change. No change to collision or authored gameplay transforms.

## RGBA qualifications
Darkvisible3 vs original16paint stack is not RGBA byteidentical. At4× there are internal AA differences near original subpixel color boundaries: see `dark-visible-validation/report.json` and exact difference locations. No large missing component or alpha hole was found. Root directed no shape distortion merely to force these original stack AA pixels to0.

## Safe cull result and limitation
Only whole original closed subpaths whose exactBezierBBox+strokeRadius is disjoint from finalclipBBox are removed. All retained absolute `M...Z` command substrings are byteexact; holes/enclosing contours that can affect the clip are retained. BBox order is `[xMin,xMax,yMin,yMax]`, not `[x0,y0,x1,y1]`.
- New color segments9940→5426;565 irrelevant subpaths removed,45.4% reduction in this normalized explicit-segment count.
- Minimum omitted strokeBBox separation from clipBBox1.06817757sourcepx.
- No original5asset path was removed. Removing hidden parts of those original assets has not been proven safe and is not applied.
- Cull is geometrically equivalent inside the clip, but rasterRGBA is not byteexact.
- Full4× overlay:298 changedpixels;279delta1,16delta2,one eachdelta4/5/9. Alpha6pixels,max4. PeakunpremultipliedRGBdelta9 occurs atalpha29; maximumpremultipliedRGBdelta2. Newwarmpaint36pixels,max2. Physicalguard0; flatopaque5×5interiorchanges0.
- ActualNative1.65 spotviews:1700 has6pixels/max3,2500 has1pixel/max1,2900 has0;alpha0. Independent local1world/full.25world d847→1afe comparisonRGBA0. Parent's full71view comparison remains authoritative.
- `optimization/aa-qualification/` contains full/source heatmaps, peak before/after/diff, exact locations and Native actualscale marker images. These were directly inspected; no detail omission or visible new cut was observed in the inspected comparisons.
- First cull reserialized retained paths; exact-string cull produced the same AA differences. The earlier serialization-cause hypothesis is withdrawn. Compound extent/path rasterization numerical effects are a hypothesis, not a proven renderer bug. No renderer fix or bounds workaround was made.

## Residual visual references / stopping boundary
Root viewed whole context and directed no further art expansion:
- Upper1000 long blue/dark sideplane: retained; generated source itself has a nearly vertical natural boundary. See `upper-sideplane-provenance.json`.
-1700 small apex: final point hits are inside new sourcefacet rim; actual source3/143 and5/154 curves contain the junction. See `junction-1700-final-rim-provenance.json`.
-3100 lower blue/dark plane: retained as cliff front/side reference, not automatically classified as a defect solely because vertical.
- Beige and darkbottom explicit cut corrections are reviewed in context; actualChromium still must confirm at full pans and gameplay scale. Normal gameplay remains separately unverified.

## Reproduction entry points
1. Trace action/logs: `trace-nonstacked.py`, `trace8/`.
2. Source contour audit/actual masks: `mask-planning/` and sibling `../warm-connection-study/`.
3. Registered candidates and all rejected comparisons preserved; scripts name their inputs/outputs.
4. Beige extraction: sibling `beige-tip-analysis/boolean-extraction/nonstack`; integration `integrate-beige-planes.py`, `integrate-beige-nonstack.py`.
5. Darkvisible exact extraction: `extract-dark-visible-patches.py`, `extract-dark-visible-grass.py`, `integrate-dark-visible.py`.
6. Actualpaint validation: `measure-final-overlay.py`; no underlying art conceals alpha holes.
7. Cull: `optimize-exact-subpath-chunks.py`; AA qualification scripts in `optimization/`.
8. Source manifest hashes: `FINAL-ARTIFACT-HASHES.json`.
