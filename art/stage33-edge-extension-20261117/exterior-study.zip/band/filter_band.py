import json,re,hashlib,copy
from pathlib import Path
from lxml import etree as E
from svgpathtools import parse_path
src=Path('/tmp/honro-stage33-exterior-v3-native/04-final.svg');out=Path('/tmp/honro-stage33-exterior-v3-band');reg=json.loads(Path('/tmp/honro-stage33-exterior-registration-v3.json').read_text());a=reg['sourceToGenerated'];left=a['tx'];right=a['tx']+1983*a['sx'];bottom=a['ty']+793*a['sy'];W,H=reg['generatedSize'];ns='http://www.w3.org/2000/svg';tag=lambda t:'{'+ns+'}'+t
original=E.parse(src);tree=copy.deepcopy(original);rows=[];oldseg=newseg=oldsub=newsub=anchors=0
alpha=original.find('.//'+tag('clipPath'));alpha_bytes=E.tostring(alpha)
for pi,node in enumerate(tree.findall('.//'+tag('path'))):
 if any(p.tag==tag('defs')for p in node.iterancestors()):continue
 assert not any(p.get('transform')for p in [node,*node.iterancestors()]),'Unexpected transform'
 current=0j;kept=[]
 for si,chunk in enumerate(re.findall('[Mm][^Mm]*',node.get('d'))):
  before=current;p=parse_path(chunk,current_pos=current);assert len(p)>0;current=p.end
  x0,x1,y0,y1=p.bbox();n=len(p);oldseg+=n;oldsub+=1
  keep=(x1>=0 and x0<=right and y1>=0 and y0<=H and (x0<=left or y1>=bottom))
  if keep:
   prefix='' if chunk[0]=='M' else f'M {before.real:.17g},{before.imag:.17g} '
   restored=parse_path(prefix+chunk);assert len(restored)==n
   for aa,bb in zip(p,restored):
    assert type(aa)==type(bb)
    for t in [0,.25,.5,.75,1]:assert abs(aa.point(t)-bb.point(t))<=1e-9
   kept.append(prefix+chunk);newseg+=n;newsub+=1;anchors+=bool(prefix)
  rows.append({'path':pi,'subpath':si,'kept':keep,'bboxGenerated':[x0,y0,x1,y1],'segments':n,'originalDsha256':hashlib.sha256(chunk.encode()).hexdigest(),'relativeContextAnchor':bool(keep and chunk[0]=='m')})
 if kept:node.set('d',''.join(kept))
 else:node.getparent().remove(node)
def wrap(t):
 root=t.getroot();defs=root.find(tag('defs'));cp=E.SubElement(defs,tag('clipPath'),id='exterior-band',clipPathUnits='userSpaceOnUse');E.SubElement(cp,tag('path'),d=f'M0 0H{left:.17g}V{bottom:.17g}H{right:.17g}V{H}H0Z')
 group=E.Element(tag('g'),attrib={'clip-path':'url(#exterior-band)'})
 for child in list(root):
  if child is not defs:root.remove(child);group.append(child)
 root.append(group)
wrap(original);wrap(tree)
assert E.tostring(tree.find('.//'+tag('clipPath')))==alpha_bytes,'Original alpha clip changed'
for name,t in [('unfiltered-band.svg',original),('filtered-band.svg',tree)]:t.write(str(out/name),encoding='utf-8',xml_declaration=True)
report={'source':str(src),'sourceSHA256':hashlib.sha256(src.read_bytes()).hexdigest(),'registration':a,'generatedBand':{'leftX':left,'bottomY':bottom,'rightX':right},'sourcePolicy':'(x<0 OR y>=793) AND x<=1983; intersect existing generated page. Original coordinates unchanged.','originalPaintSubpaths':oldsub,'retainedPaintSubpaths':newsub,'removedPaintSubpaths':oldsub-newsub,'originalPaintSegments':oldseg,'retainedPaintSegments':newseg,'relativeContextAnchors':anchors,'originalBytes':src.stat().st_size,'filteredBytes':(out/'filtered-band.svg').stat().st_size,'originalPathsIncludingAlpha':len(E.parse(src).findall('.//'+tag('path'))),'filteredPathsIncludingAlphaAndBand':len(tree.findall('.//'+tag('path'))),'embeddedImages':len(tree.findall('.//'+tag('image'))),'alphaClipByteIdentical':True,'retainedSourceChunksVerbatim':True,'retainedCurveSamplesMaxErrorBound':1e-9,'note':'Context M anchors have no drawn segment. Raw original subpath text follows unchanged; no Boolean, rounding, simplification or new geology. Bbox omission only; final band uses geometric clip.'}
(out/'filter-metrics.json').write_text(json.dumps(report,indent=2)+'\n');(out/'subpath-inventory.json').write_text(json.dumps(rows,separators=(',',':'))+'\n');print(json.dumps(report,indent=2))
